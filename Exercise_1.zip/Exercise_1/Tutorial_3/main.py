# Tutorial 3: Data Structure: Lists, Tuples, Dictionaries.

# Exercise 1: The Concert Attendance [4 Marks]
# Scenario: Pat is organizing a concert and tracking the attendance each hour in a list:
# attendance = [50, 75, 150, 200]. Pat realizes they forgot to add the initial count of 25
# attendees. Help Pat by adding this number at the beginning of the list and print the
# updated list.
# Task: Add 25 to the beginning of the attendance list and print the new list.

# attendance = [50, 75, 150, 200]
#
# # Adding 25 to the beginning of the attendance list
# attendance.insert(0,21)
#
# print(attendance)









# Exercise 2: The Unique Item Counter [6 Marks]
# Scenario: Jordan is analyzing social media posts and wants to count the unique
# hashtags used. They have a list of hashtags from several posts: hashtags = ["#python",
# "#coding", "#python", "#data", "#coding", "#data", "#machinelearning"]. Jordan
# needs to find the total number of unique hashtags.
# Task: Write a Python script to find and print the number of unique hashtags in the list.


# hashtags = ["#python", "#coding", "#python", "#data", "#coding", "#data", "#machinelearning"]
# unique_hashtags = []
# count = 0
#
# for hashtag in hashtags:
#     if hashtag not in unique_hashtags:
#         unique_hashtags.append(hashtag)
#
# for hashtag in unique_hashtags:
#     print(hashtag)
#     count = count + 1
#
# print("The number of unique hashtags in the list is: ",count)














# Exercise 3: The Recipe Ingredients [4 Marks]
# Scenario: Casey is preparing to bake a cake and has a tuple with ingredients:
# ingredients = ("flour", "sugar", "eggs", "butter"). Casey wants to know if "sugar" is in
# the ingredients.
# Task: Write a Python script to check if "sugar" is in the ingredients tuple and print the
# result.

# ingredients = ("flour", "sugar", "eggs", "butter")
#
# for ingredient in ingredients:
#     if ingredient == "sugar":
#         print("The sugar is in the ingredients tuple")








# Exercise 4: The Tuple Swap Challenge [6 Marks]
# Scenario: Alex and Pat decide to swap their favourite books and movies lists for the
# weekend. Alex’s favourites are in a tuple: alex_favorites = ("1984", "Inception") and
# Pat’s are in another tuple: pat_favorites = ("The Catcher in the Rye", "Blade Runner").
# They want to swap their favourites but do it in a single line of code.
# Task: Swap the contents of alex_favorites and pat_favorites using a one-liner and
# print the new tuples.



# Original favorites
# alex_favorites = ("1984", "Inception")
# pat_favorites = ("The Catcher in the Rye", "Blade Runner")
#
# # Swap the contents of the tuples in a single line
# alex_favorites, pat_favorites = pat_favorites, alex_favorites
#
# # Print the new tuples
# print("Alex's favorites after swap:", alex_favorites)
# print("Pat's favorites after swap:", pat_favorites)










# Exercise 5: The Quick Poll [4 Marks]
# Scenario: Jordan is conducting a quick poll on the group’s favourite programming
# languages. The initial results are in a dictionary: poll_results = {"Alex": "Python",
# "Casey": "JavaScript"}. Jordan wants to add their own favourite language, "C#", to the
# poll.
# Task: Add "Jordan": "C#" to the poll_results dictionary and print the updated dictionary


# poll_results = {"Alex": "Python", "Casey": "JavaScript"}
#
# poll_results.update({"Jordan":"C#"})
#
# print(poll_results)







# Exercise 6: The Inventory Update [6 Marks]
# Scenario: Pat’s small business is keeping track of inventory in a dictionary: inventory =
# {"pencils": 30, "notebooks": 44, "erasers": 25}. A recent delivery has brought in
# additional items: new_stock = {"pencils": 10, "notebooks": 20, "markers": 15}. Pat
# needs to update the inventory by adding the new stock, including adding any new item
# types.
# Task: Write a Python script to update the inventory with new_stock and print the
# updated inventory.



# Original inventory
inventory = {"pencils": 30, "notebooks": 44, "erasers": 25}

# New stock
new_stock = {"pencils": 10, "notebooks": 20, "markers": 15}

# Update the inventory with new_stock
for item, quantity in new_stock.items():
    inventory[item] = inventory.get(item, 0) + quantity

# Print the updated inventory
print("Updated Inventory:")
for item, quantity in inventory.items():
    print(f"{item}: {quantity}")
